// const mailjet =require('node-mailjet').connect,)
const Mailjet = require('node-mailjet');
const mailjet= new Mailjet(
  {
    apiKey:"7f117b55ac1b6d3700fd55f2eca6615c",
   apiSecret:"e0042dc7648ca07e5b1abfb1b0f4004a"
}
)
 module.exports=function(email,msg){   
  const request = mailjet.post('send', { version: 'v3.1' }).request({
    Messages: [
      {
        From: {
          Email: 'abhishekkashyap1210@gmail.com',
          Name: 'Me',
        },
        To: [
          {
            Email: email,
            Name: 'You',
          },
        ],
        Subject: 'My first Mailjet Email!',
        TextPart: 'Greetings from Mailjet!',
        HTMLPart:
          '<h3>Dear passenger 1, welcome to <a href="https://www.mailjet.com/">Mailjet</a>!</h3><br />May the delivery force be with you!<br />'+msg,
      },
    ],
  })
  request
    .then(result => {
      console.log(result.body)
    })
    .catch(err => {
      console.log(err.statusCode)
    })}
