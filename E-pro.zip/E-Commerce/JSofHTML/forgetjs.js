const forget=document.getElementById('forget');
const forcur=document.getElementById('forcur');
const forcur2=document.getElementById('forcur2');
const change=document.getElementById('Change');
const pass=document.getElementById('newPassword');
const intemail=document.getElementById("email");
const gotohome = document.getElementById('gotohome');
const cpass=document.getElementById('confirmNewPassword');
const sendotp=document.getElementById("sendotp");
const len=document.getElementById("len");
const Updatepass=document.getElementById("Updatepass");
const inputs = document.getElementById("inputs");
const err=document.getElementById("err");
const digit=document.getElementById("digit");
const low=document.getElementById("low");
const upp=document.getElementById("upp");

const popup = document.getElementById('popup');
const without=document.getElementById("without");
const cpp=document.getElementById("cpp");
const p5=document.createElement('p');
const logindata = new URLSearchParams(window.location.search);
var ob=logindata.get("user")
let le=0,u=0,l=0,d=0,cp=0,so=0,g=0,g2=0;
let oldpass='';
let t=0;
let userid='';
if(err)
{
    t=1
}

if(t){
    userid=err.innerText;
    find(function(x){});
    forget.style.display="none";
    change.style.display="block";
    const la=document.createElement('label');
    la.setAttribute("for","currentPassword");
    const intt=document.createElement('input');
    intt.setAttribute("name","currentPassword");
    // intt.setAttribute("id","currentPassword");
    intt.setAttribute("type","Password");
    la.innerText="Current Password:";
    forcur.appendChild(la);
    forcur.appendChild(intt);
    p5.setAttribute("style","color: red;" );
    forcur.appendChild(p5);
    intt.addEventListener("keyup",function(event){
    if(event.key==='click'){
        p5.innerText="";
    }
    if(intt.value===oldpass){
        g2=1;         
    }
    else{
        g2=0;        
    }
})

}
else
{
    change.style.display="none";
    forget.style.display="block";
    
    const la=document.createElement('label');
    la.setAttribute("for","email");
    const intt=document.createElement('input');
    intt.setAttribute("name","email");
    intt.setAttribute("type","email");
    const p=document.createElement('p');
    p.setAttribute("style","color: red;" );
    la.innerText="Email:";
    forcur2.appendChild(la);
    forcur2.appendChild(intt);
    forcur2.appendChild(p);
    sendotp.addEventListener('click',function(){
        userid=intt.value;

        find(function(x)
        {
        if(x){
        let temp=Math.floor(100000 + Math.random() * 900000);
        so=temp;
        fetch('/sendmail',{
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({email:intt.value,
                msg:'OTP is'+temp,
            }),
          }) 
        }
        else
        {
            p.innerText="Username Not exits";
        }
        });
        
    })
    
   intt.addEventListener("click",function(event){
    p.innerText="";
})
}
pass.addEventListener("keyup",function(event){
    let temp=pass.value;    
    if(temp)
    {
      
     if((temp.length)>=8){
      len.style.color="green";  
      le=1;
     }
     else{
      len.style.color="red";
      le=0;
     }
    }else{
        len.style.color="red";
        le=0;
       }

      if(temp.match(/[0-9]/)){
        digit.style.color="green";
        d=1;    
    }else{
       digit.style.color="red";
       d=0;
    } 


     if(temp.match(/[a-z]/)){
        low.style.color="green";    
        l=1;
    }else{
       low.style.color="red";
       l=0;
    }

    if(temp.match(/[A-Z]/)){
        u=1;
        upp.style.color="green";    
    }else{
       upp.style.color="red"; 
       u=0;
    }
    if(pass.value===cpass.value){
        cp=1;
        cpp.style.color="green"; 
    }
    else{
        cp=0;
        cpp.style.color="red"; 
    }
});
cpass.addEventListener("keyup",function(event){
    if(pass.value===cpass.value){
        cp=1;
        cpp.style.color="green"; 
    }
    else{
        cp=0;
        cpp.style.color="red"; 
    }
})

Updatepass.addEventListener('click',function(e){
    e.preventDefault();
    let h="";
        for (let intc of inputs.children) {
             h+=intc.value;
    
        }
        h=+h;
        if(so==h){
           g2=1;
        }
        else
        {
            p5.innerText="Wrong OTP";
            forget.appendChild(p5);
        }
        if(!g2&&!so)
        {

            p5.innerText="Wrong password";
        }
        else{
       if(cp&&u&&le&&l&&d&&g2){
        fetch('/password-update',{
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({email:userid,
                password :pass.value,
            })
        }).then(function(res){
            if(res.status===200){
            fetch('/sendmail',{
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({email:userid,
                    msg:"Password Successfully Updated",
                }),
              })
              popup.style.display='block';
              without.style.display='none';

            }
        })
        }
      
}
})

function find(callback){
    let y=0;
    fetch('/find-data',{
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({email:userid,
        })
    }).then(function(res){
       
        if(res.status==200)
        {
            return res.json();
        }
          
    }).then(function (data) {
        if(data){
       oldpass=data.password;
       if(oldpass){
        y=1;
        callback(y);

     }
      }
      else
      {
        callback(y);
      }
    })
    
}
inputs.addEventListener("input", function (e) {
    const target = e.target;
    const val = target.value;
    if (isNaN(val)) {
        target.value ="";
        return;
    }

    if (val != "") {
        const next = target.nextElementSibling;
        if (next) {
            next.focus();
        }
    }
});

inputs.addEventListener("keyup", function (e) {
    const target = e.target;
    const key = e.key.toLowerCase();

    if (key == "backspace" || key == "delete") {
        target.value = "";
        const prev = target.previousElementSibling;
        if (prev) {
            prev.focus();
        }
        return;
    }
});
gotohome.addEventListener('click',function(){
    location.href="/Homepage";
  });