const newpro=document.getElementById("newpro");
const gotohome = document.getElementById('gotohome');
const Grandtotal = document.getElementById('Grandtotal');
const logindata = new URLSearchParams(window.location.search);
oldproduct();
gotohome.addEventListener('click',function(){
   location.href="/Homepage";
});




function oldproduct(){
    
    fetch('/cart-product',{
      method: "POST",
      
    }).then(function(res){
      if(res.status===200)
         return res.json();
    })
    .then(function (data) {
       data.products.forEach(function (x) {
        fetch('/find-product',{
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({id:x.productid,          
          }),
        }).then(function(res){
          if(res)
             return res.json();
        })
        .then(function (data3) {
          showproduct(data3,x);

        })
      });
      
    })
}
function showproduct(data,q){
   
    const div1=document.createElement('p');   
    const div2=document.createElement('div'); 
    div2.setAttribute("class","product")       
    const br=document.createElement('br');  

    const img=document.createElement('img');  
    img.src=data.productimg;
    const h2=document.createElement('span'); 
    h2.innerText=data.productName;       
    const p1=document.createElement('p'); 
    p1.innerText=data.productPrice  
    h2.setAttribute("id","names")   

    const p2=document.createElement('span'); 
    const p3=document.createElement('span'); 
    const p4=document.createElement('span'); 
    p3.innerHTML=`<span class="material-symbols-outlined"style="background-color :lightblue;">remove</span>  `;
    p4.innerHTML=`  <span class="material-symbols-outlined"style="background-color: lightblue;">add</span><br>`;
    p2.innerText=q.quantity;
    const b1=document.createElement('button');   
    const b2=document.createElement('button'); 
    b1.innerHTML="DELETE";
    b2.innerHTML="View Details"
    div1.innerHTML="Total price is :"+(data.productPrice*q.quantity);
    if(Grandtotal.innerText){
      Grandtotal.innerText=(+Grandtotal.innerText)+(data.productPrice*q.quantity);
    }
    else
    {
      Grandtotal.innerText=(data.productPrice*q.quantity);     
    }
    div2.appendChild(img);
    div2.appendChild(br);  
    div2.appendChild(h2);  
    div2.appendChild(p1);  
    div2.appendChild(p3);  
    div2.appendChild(p2);
    div2.appendChild(p4);  
 
    div2.appendChild(b1);
    div2.appendChild(b2);
    div2.appendChild(div1);
    newpro.appendChild(div2);
    p3.addEventListener('click',function(){

      if(q.quantity>1){
          q.quantity--;
          fetch('/cart-product-quantity',{
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({id:q.productid,num:q.quantity,         
            }),
          })
    div1.innerHTML="Total price is :"+(data.productPrice*q.quantity);
    Grandtotal.innerText=(+Grandtotal.innerText)-(data.productPrice);

      }
      else
      {
       
      swal({  
        title: " Oops!",  
        text: "Number quantity always greater than 1",  
        icon: "error",  
        button: "oh no!",  
      });  
     
      }
      p2.innerText=+q.quantity;
    })
    p4.addEventListener('click',function(){
   
      if(data.productquantity==q.quantity){
       
        swal({  
          title: " Oops!",  
          text: "Number quantity Not available",  
          icon: "error",  
          button: "oh no!",  
        });  
      }
      else{
          q.quantity++;
          fetch('/cart-product-quantity',{
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({id:q.productid,num:q.quantity,         
            }),
          })
    div1.innerHTML="Total price is :"+(data.productPrice*q.quantity);
    Grandtotal.innerText=(+Grandtotal.innerText)+(data.productPrice);

      p2.innerText=q.quantity;
        }
    })
     b1.addEventListener('click',function(){
      Grandtotal.innerText=(+Grandtotal.innerText)-(data.productPrice*q.quantity);
      div2.removeAttribute("class")
      div2.innerText="";
      fetch('/cart-product-delete',{
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({id:q.productid,         
        }),
      })

     })
     b2.addEventListener('click',function(){
      
     
      swal({  
        title: "Description",  
        text: data.productDescription,  
   
        button: "Okay!",  
     });
    })
}