const openPopup=document.getElementById("openPopup");
const popup = document.getElementById('popup');
const viewmore = document.getElementById('viewmore');
const cartr = document.getElementById('cartr');
const err=document.getElementById("err");
const newpro=document.getElementById("newpro");
const homelogin = document.getElementById('homelogin');
const homeres = document.getElementById('homeres');
const loged = document.getElementById('loged');
const unloged = document.getElementById('unloged');
const NAC = document.getElementById("NAC");
const productadd = document.getElementById("productadd");
const changepass = document.getElementById("changepass");
let num=5;
let skip=0;


if(err){
  if(err.innerText=="1"){
    productadd.style.display="block";
    NAC.style.display="block";
  }
  else if(err.innerText=="2")
  {
    productadd.style.display="block";
  }
  loged.style.display="block";
  unloged.style.display="none";
}else
{
  unloged.style.display="block";
  loged.style.display="none";
}

NAC.addEventListener('click',function(){
  location.href="/Network-Access-Control";
})
productadd.addEventListener('click',function(){
  location.href="/Update-Products-details";
})

homelogin.addEventListener('click',function(){
    location.href="/login";
})
homeres.addEventListener('click',function(){
    location.href="/reg"
})
oldproduct(skip,num);

viewmore.addEventListener('click',function(){
    num+=5;
    skip+=5;
    oldproduct(skip,num);
})
openPopup.addEventListener('click', (e) => {
    if (openPopup.classList.contains("xy")) {
      popup.style.display = 'none';
      openPopup.removeAttribute("class")
    }
    else {
      popup.style.display = 'block';
      openPopup.setAttribute("class", "xy")
    }
  });

  function oldproduct(s,n){
    fetch('/product-informations',
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
          skip:s,
          itemNo :n,
      }),
    }).then(function(res){
        if(res){
          return res.json();
        }
    }).then(function (data) {
      if(data.length<5)
      {
        viewmore.style.display="none";
      }
      else
      viewmore.style.display="block";
      
     
       for(let i=0;i<data.length;i++)
       {
        showproduct(data[i]);
       }
    
      
    })
}

  function showproduct(data){
    const b1=document.createElement('button');   
    const b2=document.createElement('button');
    const br=document.createElement('br');  

    const div1=document.createElement('div');   
    const div2=document.createElement('div'); 
    div2.setAttribute("class","product")       
    const img=document.createElement('img');  
    img.src=data.productimg;
    const h2=document.createElement('span'); 
    h2.setAttribute("id","names")   
    h2.innerText=data.productName;       
    const p1=document.createElement('p'); 
    p1.innerText=data.productPrice  
    const p2=document.createElement('p'); 
    p2.innerText=data.productDescription;
    b1.innerHTML="Add to Cart";
    
   
    b2.innerHTML="View Details"
    
    div2.appendChild(img); 
    div2.appendChild(br);  
    div2.appendChild(h2);  
    div2.appendChild(p1);  
    // div2.appendChild(p2);  
    div2.appendChild(b1);
    div2.appendChild(b2);
    div1.appendChild(div2);
    newpro.appendChild(div1);

    b1.addEventListener('click',function(){
      if(err){
      let str=b1.innerText;
      if(str==="Add to Cart"){
      fetch('/Add-to-cart',{
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            proId :data.productId,
        }),
      })
        b1.innerText="GO to Cart";
      }
      else
      {
        location.href="/Add--to--cart";

      }
    }
    else
    {
      notlogin()      
    }
    })
    b2.addEventListener('click',function(){
      
      
      swal({  
         title: "Description",  
         text: "Product Name: "+data.productName+"\nProduct Price: "+data.productPrice+"\n"+data.productDescription,  
    
         button: "Okay!",  
      });  
    })
    
}

changepass.addEventListener('click',function(){
  location.href="/change-password";
})
cartr.addEventListener('click',function(){
  if(err){
    location.href="/Add--to--cart";
  }
  else
     notlogin();
})
function notlogin(){
  swal({  
    title: "Please login first",    
    buttons: {
      skip: {
        text: "Not now",
        visible: true,
        closeModal: true
    },
      login: {
          text: "Go to login page",
          visible: true,
          closeModal: true
      },
      
     
  },   
  }).then((value) => {
  if (value === "login"){
    location.href="/login";
  }
});
}