const openPopupButton = document.getElementById('openPopup');

const popup = document.getElementById('popup');
const gotohome = document.getElementById('gotohome');
const NAC = document.getElementById("NAC");
const adminids = document.getElementById("Adminids");
const reloadNAC = document.getElementById("reloadNAC");


const userids = document.getElementById("userids");

const NACdiv = document.getElementById("NACdiv");
const productdiv = document.getElementById("productdiv");

ncafun();
gotohome.addEventListener('click',function(){
  location.href="/Homepage";
});

reloadNAC.addEventListener('click',function(){
  location.href="/Network-Access-Control";
})
function Idsshow(data){
   if("abhishekkashyap1210@gmail.com"!==data.userId){
        const div1=document.createElement('div');      
        const div2=document.createElement('div');        
        const div3=document.createElement('div');        
        const div4=document.createElement('div');   
        let input = document.createElement("input");
        input.type = "checkbox";     
        div1.setAttribute("id","udiv" );
        div2.setAttribute("id","udivu" );
        div3.setAttribute("id","udivp" );
        div4.setAttribute("id","udivb" );


       
        div2.innerText=data.userId;
        div3.innerText=data.password;
        div1.appendChild(div2);
        div1.appendChild(div3);
        div1.appendChild(div4);
       if(data.flag)
       {
            div4.innerHTML='REMOVE ADMIN';
            div4.appendChild(input);
            input.checked = 'true';
            adminids.appendChild(div1);
       }
       else
       {    

        div4.innerHTML='MAKE ADMIN ';
        div4.appendChild(input);
        userids.appendChild(div1);
       }
       input.addEventListener("click", function () {
          
        fetch("/update", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            user: data.userId,
          }),
        })
          .then(function (res) {
            if (res.status === 404) {
              console.log("ERRR")
    
            }
          })
    
      });
   }
}
function ncafun(){
   
  fetch('/user-informations').then(function(res){
      if(res){
        return res.json();
      }
  }).then(function (data) {
     data.forEach(function (x) {
      Idsshow(x);
    });
    
  })

}