const mongoose=require("mongoose");
const userschema= new mongoose.Schema({
    userid :String,
    products:[{productid : Number,quantity: Number}],
});
const user=mongoose.model("card",userschema);
module.exports=user;