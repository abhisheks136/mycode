const express = require("express");
const session = require("express-session");
const multer = require('multer')
const upload = multer({ dest: 'productimg/' });

const db = require("./E-mongodb");
const sendmail = require("./mail");

const usermd = require("./user-information");
const productmd = require("./product-information");
const cardmd = require("./card-information");

// const usermmd=require("./usermetadata");
const fs = require("fs");

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }))
app.use(express.static("productimg"))
app.use(upload.single('productimg'));

app.use(express.static("JSofHTML"))
app.use(session({
  secret: "helllo",
  resave: true,
  saveUninitialized: true,
}))

app.set("view engine", "ejs");
app.use(function (req, res, next) {
  console.log(req.method, req.url);
  next();
});



app.get("/", function (request, response) {
  response.redirect("/Homepage");
})

app.get("/login", function (request, response) {
  if (request.session.abhh) {
    response.redirect("/Homepage");
  }
  else
    response.render("E-login", { error: null })

})
app.post("/login", function (request, response) {
  user = request.body.username;
  let pass = request.body.password;
  if (user && pass) {
    usermd.findOne({ userId: user }).then(function (res) {
      if (res) {
        if (res.password === pass) {
          request.session.abhh = user;

          if (res.userId === "abhishekkashyap1210@gmail.com") {
            request.session.e = 1;
          }
          else if (res.flag) {
            request.session.e = 2;
          }
          else {
            request.session.e = 3;
          }
          response.redirect("/Homepage");
        } else {
          response.render("E-login", { error: "Username and password wrong", })
        }

      }
      else {
        response.render("E-login", { error: "Username Not exits", })
      }
    });
  }
  else
    response.redirect("/login");

});


app.get("/Homepage", function (request, response) {
  if (request.session.abhh) {

    response.render("home", { error: request.session.abhh, err: request.session.e });
  }
  else {
    response.render("home", { error: null, err: null });
  }
})

app.get("/Network-Access-Control", function (request, response) {
  if (request.session.abhh === "abhishekkashyap1210@gmail.com")
    response.render("DBA");
  else
    response.redirect("/Homepage");
});
app.get("/Update-Products-details", function (request, response) {
  //if(request.session.abhh){
  if (request.session.e == 1 || request.session.e == 2) {

    response.render("productadd");
  }
  else
    response.redirect("/Homepage");
  // } else{
  // response.redirect("/Homepage");  
  //}
})
app.get("/reg", function (request, response) {
  if (request.session.abhh) {
    response.redirect("/Homepage");
  }
  else {
    let err = request.query.errr;
    if (err) {
      if (err === "Username already exits" || err === "Failed to save in file") {

        response.render("E-reg", { error: err })
        return;
      }
      else {
        response.redirect("/reg");
      }
    } else
      response.render("E-reg", { error: null });
  }
});
app.get("/user-informations", function (request, response) {
  if (request.session.abhh === "abhishekkashyap1210@gmail.com") {
    usermd.find().then(function (res) {
      response.send(res);
    })
  }
  else {
    response.redirect("/Homepage");
  }
});
app.post("/product-informations", function (request, response) {
  temp=request.body;
  productmd.find().skip(temp.skip).limit(temp.itemNo).then(function (res) {
    response.send(res);
  })
});
app.post("/productdetailupdate", function (request, respose) {
  let temp = request.body;

  productmd.findOneAndUpdate({ productId: temp.id }, { productName: temp.n, productquantity: temp.q, productPrice: temp.p, productDescription: temp.d }).then(function (res) {
    if (res) {
      respose.status(200);
      respose.send(res);
    }
    else {
      respose.status(404);
      respose.send();
    }
  })

})
app.post("/productdetailsave", function (request, respose) {
  let temp = request.body;
  temp.productimg = request.file.filename;
  productmd.create(temp).then(function (res) {
    if (res) {
      respose.status(200);

      respose.send(res);
    }
    else {
      respose.status(404);
      respose.send();
    }
  })
})
app.post("/reg", function (request, response) {
  let email = request.body.email;
  let pass = request.body.password;
  let temp = {
    userId: email,
    password: pass,
    profilepic: "",
    flag: 0,
  }
  usermd.create(temp).then(function (res) {
    if (res) {
      response.status(200);
      response.send();
    }
    else {
      response.status(402);
      response.send();
    }
  })


});
app.post("/sendmail", function (request, response) {
  let email = request.body.email;
  let temp = request.body.msg;
  usermd.findOne({ userId: temp.userId }).then(function (res) {
    if (res) {
      response.status(205);
      response.send();
    }
    else {
      sendmail(email, temp);
      response.send();
    }
  });


})
app.get("/Log-out", function (request, response) {
  request.session.destroy();
  response.redirect("/login");
});


db.init().then(function () {
  app.listen(2000, function () {
    console.log("server is running on port�2000");
  });
})
app.post("/update", function (request, respose) {
  temp = request.body;
  usermd.findOne({ userId: temp.user }).then(function (res) {
    if (res) {
      if (res.flag) {
        res.flag = 0;
      }
      else
        res.flag = 1;
      usermd.updateOne({ userId: temp.user }, { flag: res.flag }).then(function (res) {
        if (res) {
          respose.send();
        }
        else {
          respose.status = 404;
          respose.send(err);

        }
      });
    }
    else {
      respose.status = 404;
      respose.send(err);

    }
  });


});

app.post("/password-update", function (request, respose) {

  temp = request.body;
  usermd.updateOne({ userId: temp.email }, { password: temp.password }).then(function (res) {
    if (res) {
      respose.status(200);
      respose.send();
    }
    else {
      respose.status(404);
      respose.send(err);

    }
  });


});
app.post("/find-data", function (request, respose) {

  temp = request.body;
  usermd.findOne({ userId: temp.email }).then(function (res) {
    if (res) {
      respose.status(200);
      respose.json(res);
    }
    else {
      respose.status(208);

      respose.send();
    }
  });
});
app.post("/find-product", function (request, respose) {

  temp = request.body;
  productmd.findOne({ productId: temp.id }).then(function (res) {
    if (res) {
      respose.status(200);
      respose.json(res);
    }
    else {
      respose.status(208);

      respose.send();
    }
  });
});

app.post("/cart-product", function (request, respose) {
  if (request.session.abhh) {
    cardmd.findOne({ userid: request.session.abhh }).then(function (res) {
      if (res) {
        respose.status(200);

        respose.json(res);
      }
      else {
        respose.status(208);

        respose.send();
      }
    });
  }
});
app.post("/cart-product-quantity", function (request, respose) {

  temp = request.body;
  cardmd.findOne({ userid: request.session.abhh }).then(function (data) {
    if (data) {
      respose.status(200);
      data.products.forEach(function (x) {
        if (x.productid === temp.id) {
          x.quantity = temp.num;
        }
      })
      cardmd.updateOne({ userid: request.session.abhh }, { products: data.products }).then((d) => {

      })

    }
    else {
      respose.status(208);
      respose.send();
    }
  });
});
app.post("/delete-product", function (request, respose) {
  temp = request.body;
  console.log("h", temp);

  productmd.deleteOne({ productId: temp.id }).then(function (res) {
    if (res) {
      console.log(res);

      respose.send();
    }
    else {
      respose.status = 404;
      respose.send(err);

    }
  });
});
app.post("/Add-to-cart", function (request, response) {

  temp = request.body;

  cardmd.find({ userid: request.session.abhh })
    .then(data => {
      if (data.length == 0) {
        const objec = { userid: request.session.abhh, products: [{ productid: temp.proId, quantity: 1 }] };
        cardmd.create(objec);
      }
      else {
        const objec = { productid: temp.proId, quantity: 1 };
        data[0].products.push(objec);
        cardmd.findOneAndUpdate({ userid: request.session.abhh }, { products: data[0].products }).then((d) => {
          response.status(200);
          response.send();
        }).catch((error) => {
          response.status(400);
          response.send();
        });
      }
    })
});
// app.post("/delete-to-cart", function (request, response) {

//   temp = request.body;

//   cardmd.find({ userid: request.session.abhh })
//     .then(data => {
//       if (data.length == 0) {
//         const objec = { userid: request.session.abhh, products: [{ productid: temp.proId, quantity: 1 }] };
//         cardmd.create(objec);
//       }
//       else {
//         const objec = { productid: temp.proId, quantity: 1 };
//         data[0].products.push(objec);
//         cardmd.findOneAndUpdate({ userid: request.session.abhh }, { products: data[0].products }).then((d) => {
//           response.status(200);
//           response.send();
//         }).catch((error) => {
//           response.status(400);
//           response.send();
//         });
//       }
//     })
// });
app.get("/forget-password", function (request, response) {
  response.render("forget", { error: null });
});
app.get("/change-password", function (request, response) {
  if (request.session.abhh)
    response.render("forget", { error: request.session.abhh });
  else
    response.redirect("/Homepage");
});
app.get("/Add--to--cart", function (request, response) {
  if (request.session.abhh)
  response.render("card", { error: null });
  else
  response.redirect("/Homepage");
});
app.post("/cart-product-delete", function (request, respose) {
  temp=request.body;
  cardmd.findOne({userid:request.session.abhh}).then(function(data){
     if(data){
         respose.status(200);
        
          data.products=data.products.filter((x) =>{
             return x.productid!==temp.id
          })
       
         cardmd.updateOne({ userid: request.session.abhh}, { products: data.products }).then((d) => {
         
         })
     
        }
     else
     { 
      respose.status(208);
         console.log("JJJj")
          respose.send();
     }
  });
});