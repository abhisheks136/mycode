const mongoose=require("mongoose");
const userschema= new mongoose.Schema({
    userId :String,
    password:String,
    profilepic:String,
    flag: Number,
});
const user=mongoose.model("user",userschema);
module.exports=user;