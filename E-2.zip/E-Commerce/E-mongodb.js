const mongoose=require("mongoose");
module.exports.init=async function(){
    await mongoose.connect("mongodb+srv://abhi:e4fGr3w9p35jKHTN@abhishek.99uu8qn.mongodb.net/E-commerce?retryWrites=true&w=majority");
    console.log("con")
};