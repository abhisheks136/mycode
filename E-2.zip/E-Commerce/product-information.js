const mongoose=require("mongoose");
const userschema= new mongoose.Schema({
    productName:String,
    productimg:String,
    productPrice:Number,
    productDescription:String,
    productId :Number,
    productquantity :Number,

    
});
const users=mongoose.model("product",userschema);
module.exports=users;