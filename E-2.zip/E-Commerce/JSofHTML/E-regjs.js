const len=document.getElementById("len");
const intemail=document.getElementById("email");
const sendotp=document.getElementById("sendotp");
const intreg=document.getElementById("reg");
const digit=document.getElementById("digit");
const low=document.getElementById("low");
const upp=document.getElementById("upp");
const cpp=document.getElementById("cpp");
const inputs = document.getElementById("inputs");
const spe=document.getElementById("spe");
const pass=document.getElementById("password");
const cpass=document.getElementById("cpassword");
let le=0,u=0,l=0,d=0,cp=0,so=0;
const err=document.getElementById("err");
intemail.addEventListener('click',function(){
     err.style.display="none";
});
pass.addEventListener("keyup",function(event){
    let temp=pass.value;    
    if(temp)
    {
      
     if((temp.length)>=8){
      len.style.color="green";  
      le=1;
     }
     else{
      len.style.color="red";
      le=0;
     }
    }else{
        len.style.color="red";
        le=0;
       }

      if(temp.match(/[0-9]/)){
        digit.style.color="green";
        d=1;    
    }else{
       digit.style.color="red";
       d=0;
    } 


     if(temp.match(/[a-z]/)){
        low.style.color="green";    
        l=1;
    }else{
       low.style.color="red";
       l=0;
    }

    if(temp.match(/[A-Z]/)){
        u=1;
        upp.style.color="green";    
    }else{
       upp.style.color="red"; 
       u=0;
    }
    if(pass.value===cpass.value){
        cp=1;
        cpp.style.color="green"; 
    }
    else{
        cp=0;
        cpp.style.color="red"; 
    }
});
cpass.addEventListener("keyup",function(event){
    if(pass.value===cpass.value){
        cp=1;
        cpp.style.color="green"; 
    }
    else{
        cp=0;
        cpp.style.color="red"; 
    }
})

    intreg.addEventListener("click",function(){
        let er="";
        let h="";
        for (let intc of inputs.children) {
             h+=intc.value;
    
        }
        h=+h;
        
        if(so==h){
        fetch('/reg',{
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({email:intemail.value,
            password :pass.value,
        }),
      }).then((res)=>{
        
        if(res.status===402){
            er="Failed to save in file";          
            location.href="/reg?errr="+er;
        }
        else
        {    

            location.href="/login";
        }
      })
    }
    
    })
 


    inputs.addEventListener("input", function (e) {
        const target = e.target;
        const val = target.value;
    
        if (isNaN(val)) {
            target.value ="";
            return;
        }
    
        if (val != "") {
            const next = target.nextElementSibling;
            if (next) {
                next.focus();
            }
        }
    });
    
    inputs.addEventListener("keyup", function (e) {
        const target = e.target;
        const key = e.key.toLowerCase();
    
        if (key == "backspace" || key == "delete") {
            target.value = "";
            const prev = target.previousElementSibling;
            if (prev) {
                prev.focus();
            }
            return;
        }
    });
sendotp.addEventListener('click',function(){
    if(cp&&u&&le&&l&&d&&intemail.value){
        let temp=Math.floor(100000 + Math.random() * 900000);
        
        fetch('/sendmail',{
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({email:intemail.value,
                msg:temp,
            }),
          }).then((res)=>{        
            if(res.status===205){
               er="Username already exits";
                location.href="/reg?errr="+er;
            }
            else
              so=temp;
          })
    }    
})