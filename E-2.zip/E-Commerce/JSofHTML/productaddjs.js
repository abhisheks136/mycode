const newpro=document.getElementById("newpro");
const openPopup=document.getElementById("openPopup");
const popup = document.getElementById('popup');
const GOBACK = document.getElementById('GOBACK');
const GOBACK2 = document.getElementById('GOBACK2');

const viewmore = document.getElementById('viewmore');
const addnewpro = document.getElementById('addnewpro');
const gotohome = document.getElementById('gotohome');
const detaildiv = document.getElementById('detaildiv');
const adddetaildiv = document.getElementById('adddetaildiv');
const upddetaildiv = document.getElementById('upddetaildiv');
// const submitpro2=document.getElementById("submitpro2");
const productName2=document.getElementById("productName2");
const productPrice2=document.getElementById("productPrice2");
const productDescription2=document.getElementById("productDescription2");
const productquantity2=document.getElementById("productquantity2");
const submitpro=document.getElementById("submitpro");
const productimg=document.getElementById("productimg");
const productName=document.getElementById("productName");
const productPrice=document.getElementById("productPrice");
const productDescription=document.getElementById("productDescription");
const productquantity=document.getElementById("productquantity");
let num=5;
let skip=0;


oldproduct(skip,num);
viewmore.addEventListener('click',function(){
  num+=5;
 // skip+=5;
  oldproduct(skip,num);
})
gotohome.addEventListener('click',function(){
   location.href="/Homepage";
});
GOBACK.addEventListener('click',function(){
  adddetaildiv.style.display = 'none';
  detaildiv.style.display = 'block';
});
GOBACK2.addEventListener('click',function(){
  upddetaildiv.style.display = 'none';
  detaildiv.style.display = 'block';
});
addnewpro.addEventListener('click',function(){
  detaildiv.style.display = 'none';
  adddetaildiv.style.display = 'block';
});
openPopup.addEventListener('click', (e) => {
  if (openPopup.classList.contains("xy")) {
    popup.style.display = 'none';
    openPopup.removeAttribute("class")
  }
  else {
    popup.style.display = 'block';
    openPopup.setAttribute("class", "xy")
  }
});
submitpro.addEventListener('click',function(e){
     e.preventDefault();
     if(productimg.value&&productName.value&&productPrice.value&&productDescription.value&&productquantity.value){
        let a=new FormData();
        a.append( "productimg",productimg.files[0]);
        a.append("productName", productName.value);
        a.append( "productPrice",productPrice.value);
        a.append("productId", Date.now());
        a.append("productDescription",productDescription.value);
        a.append("productquantity",productquantity.value);
        fetch("/productdetailsave", {
          method: "POST",
          body:a,
        })
          .then(function (res) {
            if (res.status === 404) {
              throw new Error("something worng");
  
            }
            else
              return res.json();
          }).then(function(data){
          console.log("3",num);

            if(num%5!=0){
              console.log("4",num);
              num++;
              skip++;
             console.log("5",num);
            showproduct(data);
            }
            else 
            viewmore.style.display="block";

          })
          .catch(function (error) {
            console.log(error);
          });
      } else {
        
        swal({  
          title: " Please enter valid details",  
                      
          button: "Okay!",  
       });  
      }
      productimg.value="";
      productName.value="";
      productPrice.value="";
      productDescription.value="";
      productquantity.value="";
      
});
function oldproduct(s,n){
  console.log("ns",s,n);
    fetch('/product-informations',{
          method: "POST",
         headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          skip:s,
          itemNo :n,
      }),
    }).then(function(res){
        if(res){
          return res.json();
        }
    }).then(function (data) {
      if(data.length<5&&n!=1)
      {  
          console.log("1",data.length);
          console.log("1",num);

         num= (num-(5-data.length));20/17
         skip=num;
         console.log("2",num);

        viewmore.style.display="none";
      }
      else
        skip+=5;
        
     
       for(let i=0;i<data.length;i++)
       {
        showproduct(data[i]);
       }
    
    })
}
function showproduct(data){
    //const div1=document.createElement('div');   
    const div2=document.createElement('div'); 
    div2.setAttribute("class","product")       
    const br=document.createElement('br');  

    const img=document.createElement('img');  
    img.src=data.productimg;
    const h2=document.createElement('span'); 
    h2.innerText=data.productName;       
    const p1=document.createElement('p'); 
    p1.innerText=data.productPrice;
    h2.setAttribute("id","names")   

    // const p2=document.createElement('p'); 
    // p2.innerText=data.productDescription;
    const b1=document.createElement('button');   
    const b2=document.createElement('button'); 
    b1.innerHTML="DELETE";
    b2.innerHTML="Edit Details"
    div2.appendChild(img);
    div2.appendChild(br);  
    div2.appendChild(h2);  
    div2.appendChild(p1);  
    // div2.appendChild(p2);  
    div2.appendChild(b1);
    div2.appendChild(b2);
    // div1.appendChild(div2);
    newpro.appendChild(div2);
     b1.addEventListener('click',function(){
      div2.removeAttribute("class")
      div2.innerText="";
      fetch('/delete-product',{
        method: "POST",
       headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
         id :data.productId,
      })
    }).then(function (res) {
      oldproduct((num-1),1);
    })
     });
     b2.addEventListener('click',function(){
      productName2.value=data.productName;
      productPrice2.value=data.productPrice;
      productDescription2.value=data.productDescription;
      productquantity2.value=data.productquantity;
      detaildiv.style.display = 'none';
      upddetaildiv.style.display="block";
      const submitpro2=document.createElement('button'); 
      submitpro2.innerText="Update Detail";
      upddetaildiv.appendChild(submitpro2);
      submitpro2.addEventListener('click',function(e){
        e.preventDefault();
       if(productName2.value&&productPrice2.value&&productDescription2.value&&productquantity2.value){
          fetch("/productdetailupdate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify({ id:data.productId,
               n:productName2.value,
               p:productPrice2.value,
               d: productDescription2.value,
               q:productquantity2.value}),
          })
            .then(function (res) {
              if (res.status === 404) {
                throw new Error("something worng")
              }
              else
               {

                swal({  
                  title: " Product detail Updated Successfully",  
                              
                  button: "Okay!",  
               });  
                 upddetaildiv.style.display = 'none';
                 detaildiv.style.display="block";
               }
            })
            .catch(function (error) {
              console.log(error);
            });
        } else {
          alert("asdfghiuyjfijfjkl");
        }   
     });
     })
    
}
