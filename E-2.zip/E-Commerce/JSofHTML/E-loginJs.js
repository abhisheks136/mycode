const intp=document.getElementById("password");
const icon=document.getElementById("icon");
const intemail=document.getElementById("username");

const err=document.getElementById("err");
intemail.addEventListener('click',function(){
    if(err)
     err.style.display="none";
});
icon.addEventListener('click',function(){
    if(intp.type==="text"){
       intp.type='password';
       icon.innerHTML='visibility_off';
    }
    else{
        intp.type="text";
        icon.innerHTML='visibility';
    }
})